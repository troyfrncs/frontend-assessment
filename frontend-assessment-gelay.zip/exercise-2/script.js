new Vue({
  el: '#app',
  data: {
      sections: [],
      firstAccordionOpened: false,
  },
  mounted() {
      // Read data from the JSON file
      fetch("data.json")
          .then(response => response.json())
          .then(data => {
              this.sections = data;
          });
  },
  updated() {
      // Open the first accordion on load
      if (!this.firstAccordionOpened) {
          const firstAccordion = document.querySelector('.accordion__item:first-child .accordion__item-content');
          if (firstAccordion) {
              firstAccordion.classList.add('show');
              this.firstAccordionOpened = true;
          }
      }
  },
});
